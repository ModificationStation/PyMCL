This file can be named anything so long as it says "read me" or "readme" somewhere in it's name.

This example modpack shows what your modpack zip file should look like.

This can be installed for a vanilla beta 1.7.3 minecraft install.